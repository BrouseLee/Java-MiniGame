/**
 * Mini games
 *
 * @author Lianghui Li
 * @version v1.0
 */

package guess.game.Login;

public class Login {
    private String name;
    private String password;
    private int RPSWin;
    private int TTTWin;

    public Login() {
    }

    public Login(String name, String password, int RPSWin, int TTTWin) {
        this.name = name;
        this.password = password;
        this.RPSWin = RPSWin;
        this.TTTWin = TTTWin;
    }

    public int getRPSWin() {
        return RPSWin;
    }

    public int getTTTWin() {
        return TTTWin;
    }

    public void incrementRPSWin() {
        RPSWin++;
    }

    public void incrementTTTWin() {
        TTTWin++;
    }

    public String getName() {
        return name;
    }


}
