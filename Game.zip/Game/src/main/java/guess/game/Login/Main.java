package guess.game.Login;

import guess.game.GetImages;
import guess.game.RPS.RPS;
import guess.game.TTT.TicTacToe;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Main extends Application {
    Login currentUser = LoginApp.getCurrentUser();

    @Override
    public void start(Stage primaryStage) {

        MenuBar returnMenuBar = new MenuBar();
        returnMenuBar.setMinSize(70, 30);
        Menu stripMenu = new Menu("Return menu");
        returnMenuBar.getMenus().addAll(stripMenu);
        Menu returnMain = new Menu("Return to Login");
        returnMain.setOnAction(e -> {
            LoginApp loginStage = new LoginApp();
            loginStage.start(new Stage());
            primaryStage.close();
        });
        stripMenu.getItems().addAll(returnMain);
        HBox menuHBox = new HBox();
        menuHBox.setAlignment(Pos.TOP_LEFT);
        menuHBox.getChildren().add(returnMenuBar);

        Label label1 = new Label("GAMES");
        label1.setTextFill(Color.WHITE);
        label1.setMinSize(200,100);
        label1.setFont(Font.font("Arial", 50));
        Label label2 = new Label("Click to open the game");
        label2.setTextFill(Color.WHITE);
        label2.setMinSize(150,30);
        label2.setFont(Font.font("Arial",20));

        Label userStatsLabel = new Label();
        updateStatsLabel(userStatsLabel,currentUser);
        VBox vBoxLabel = new VBox(5);
        vBoxLabel.getChildren().addAll(label1,label2,userStatsLabel);
        vBoxLabel.setAlignment(Pos.TOP_CENTER);

        Button button1 = new Button("Open RPS Game");
        button1.setMinSize(150,150);
        Button button2 = new Button("Open TicTacToe");
        button2.setMinSize(150,150);
        HBox hBoxButton = new HBox(20);
        hBoxButton.setAlignment(Pos.CENTER);
        hBoxButton.getChildren().addAll(button1,button2);

        button1.setOnAction(e ->{
                RPS rps = new RPS(currentUser);
                rps.start(new Stage());
                primaryStage.hide();
        });

        button2.setOnAction(e ->{
                TicTacToe TicTacToe = new TicTacToe(currentUser);
                TicTacToe.start(new Stage());
                primaryStage.hide();
        });

        VBox root = new VBox(50);
        root.getChildren().addAll(menuHBox,vBoxLabel,hBoxButton);
        StackPane stackPane = new StackPane();
        stackPane.getChildren().addAll(GetImages.bgMainIV,root);
        Scene scene = new Scene(stackPane, 400, 500);
        primaryStage.setScene(scene);
        primaryStage.getIcons().add(GetImages.imageViewO.getImage());
        primaryStage.setResizable(false);
        primaryStage.setTitle("Mini Games");
        primaryStage.show();
    }

    private void updateStatsLabel(Label userStatsLabel, Login currentUser) {
        if (currentUser != null) {
            userStatsLabel.setText("RPS Wins: " + currentUser.getRPSWin() + " | TTT Wins: " + currentUser.getTTTWin());
            userStatsLabel.setTextFill(Color.WHITE);
        }
    }
}

