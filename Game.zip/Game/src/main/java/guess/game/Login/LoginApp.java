package guess.game.Login;

import guess.game.GetImages;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.io.*;
import java.util.Scanner;

public class LoginApp extends Application {
    private static final String ACCOUNTS_FILE = "accounts.txt";
    private static Login currentUser;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage loginStage) {
        loginStage.setTitle("Login");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(12);
        grid.setHgap(14);

        Label nameLabel = new Label("Username:");
        GridPane.setConstraints(nameLabel, 0, 0);

        TextField nameInput = new TextField();
        nameInput.setPromptText("username");
        GridPane.setConstraints(nameInput, 1, 0);

        Label passwordLabel = new Label("Password:");
        GridPane.setConstraints(passwordLabel, 0, 1);

        PasswordField passwordInput = new PasswordField();
        passwordInput.setPromptText("password");
        GridPane.setConstraints(passwordInput, 1, 1);

        Button loginButton = new Button("Log In");
        GridPane.setConstraints(loginButton, 1, 2);

        Button registerButton = new Button("Register");
        GridPane.setConstraints(registerButton, 1, 3);

        Label statusLabel = new Label();
        GridPane.setConstraints(statusLabel, 1, 4);

        grid.getChildren().addAll(nameLabel, nameInput, passwordLabel, passwordInput, loginButton, registerButton, statusLabel);
        grid.setAlignment(Pos.CENTER);

        loginButton.setOnAction(e -> {
            String name = nameInput.getText();
            String password = passwordInput.getText();
            currentUser = findUser(name, password);
            if (currentUser != null) {
                statusLabel.setText("Login successful!");
                Main main = new Main();
                main.start(new Stage());
                loginStage.hide();
            } else {
                statusLabel.setText("Invalid username or password");
            }
        });

        registerButton.setOnAction(e -> {
            String name = nameInput.getText();
            String password = passwordInput.getText();
            registerUser(name, password, statusLabel);
        });

        Scene scene = new Scene(grid, 350, 300);
        loginStage.setScene(scene);
        loginStage.getIcons().add(GetImages.imageViewX.getImage());
        loginStage.setResizable(false);
        loginStage.show();
    }

    private Login findUser(String username, String password) {
        try {
            File file = new File(ACCOUNTS_FILE);
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                if (parts.length == 4 && parts[0].equals(username) && parts[1].equals(password)) {
                    int RPSWin = Integer.parseInt(parts[2]);
                    int TTTWin = Integer.parseInt(parts[3]);
                    return new Login(username, password, RPSWin, TTTWin);
                }
            }
            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private void registerUser(String username, String password, Label p) {
        if (username.isEmpty() || password.isEmpty()) {
            p.setText("Please enter both username and password.");
            return;
        }
        if (isUsernameExists(username)) {
            p.setText("Username already exists. Please choose a different username.");
            return;
        }
        try {
            PrintWriter writer = new PrintWriter(new FileWriter(ACCOUNTS_FILE, true));
            writer.println(username + "," + password + ",0,0");
            writer.close();
            p.setText("Registration successful!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private boolean isUsernameExists(String username) {
        try {
            File file = new File(ACCOUNTS_FILE);
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                if (parts.length >= 1 && parts[0].equals(username)) {
                    scanner.close();
                    return true;
                }
            }
            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static Login getCurrentUser() {
        return currentUser;
    }

}


