package guess.game.Test;

import guess.game.Login.Login;

public class LoginTest {
    public static void main(String[] args) {
        Login login1 = new Login("Brous","123456",1,0);
        Login login2 = new Login("Cold","123456",2,3);
        Login login3 = new Login("Lou","654321",2,3);

        System.out.println(login1.getName());
        System.out.println(login2.getRPSWin());
        System.out.println(login3.getTTTWin());

        login3.incrementTTTWin();
        System.out.println(login3.getTTTWin());

        login2.incrementRPSWin();
        System.out.println(login2.getRPSWin());
    }
}
