package guess.game.RPS;

import guess.game.GetImages;
import guess.game.Login.Login;
import guess.game.Login.Main;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static guess.game.GetImages.*;

public class RPS extends Application {
    private final Login user;
    private int num1 = 0;
    private int num2 = 0;
    private static final String Rock = "Rock";
    private static final String Paper = "Paper";
    private static final String Scissors = "Scissors";

    public RPS(Login user) {
        this.user = user;
    }

    private static final String ACCOUNTS_FILE = "accounts.txt";

    @Override
    public void start(Stage guessStage) {

        MenuBar returnMenuBar = new MenuBar();
        returnMenuBar.setMinSize(70, 30);
        Menu stripMenu = new Menu("Return menu");
        returnMenuBar.getMenus().addAll(stripMenu);
        Menu returnMain = new Menu("Return to main menu");
        returnMain.setOnAction(e -> {
            Main mainStage = new Main();
            mainStage.start(new Stage());
            guessStage.close();
        });
        stripMenu.getItems().addAll(returnMain);

        Label winTimesLabel = new Label("Win times: ");
        winTimesLabel.setTextFill(Color.WHITE);
        winTimesLabel.setFont(Font.font("Arial", 30));
        winTimesLabel.setMinSize(30, 50);
        Label winTimes = new Label();
        winTimes.setTextFill(Color.WHITE);
        winTimes.setFont(Font.font("Arial", 30));
        winTimes.setMinSize(30, 50);

        Label resultLabel = new Label();
        resultLabel.setTextFill(Color.WHITE);
        resultLabel.setFont(Font.font("Arial", 35));
        resultLabel.setMinSize(30, 75);

        Label suggestLabel = new Label("Choose the one you want to play");
        suggestLabel.setTextFill(Color.WHITE);
        suggestLabel.setFont(Font.font("Arial", 30));
        suggestLabel.setMinSize(150, 75);

        HBox menuHBox = new HBox(130);
        menuHBox.setAlignment(Pos.TOP_CENTER);
        menuHBox.getChildren().addAll(returnMenuBar, winTimesLabel, winTimes);

        HBox suggestHBox = new HBox();
        suggestHBox.setAlignment(Pos.TOP_CENTER);
        suggestHBox.getChildren().add(suggestLabel);

        HBox hBox3 = new HBox(25);
        hBox3.setAlignment(Pos.CENTER);
        hBox3.getChildren().addAll(playerImageView, resultLabel, computerImageView);

        Button btnRock = new Button();
        btnRock.setGraphic(GetImages.imageViewR);

        Button btnPaper = new Button();
        btnPaper.setGraphic(GetImages.imageViewP);

        Button btnScissors = new Button();
        btnScissors.setGraphic(GetImages.imageViewS);

        EventHandler<ActionEvent> buttonHandler = e -> {
            Button button = (Button) e.getSource();
            String choice;
            if (button == btnRock) {
                playerImageView.setImage(GetImages.imageR);
                choice = Rock;
            } else if (button == btnPaper) {
                playerImageView.setImage(GetImages.imageP);
                choice = Paper;
            } else {
                playerImageView.setImage(GetImages.imageS);
                choice = Scissors;
            }
            String computerChoice = RPSLogic.buttonAction();
            RPSLogic.checkWinner(choice, computerChoice, resultLabel);
            if (resultLabel.getText().equals("You Win")) {
                num1++;
            } else if (resultLabel.getText().equals("You Lose")) {
                num2++;
            }
            if (num1 == 3) {
                suggestLabel.setText("You Win this Round");
                btnRock.setDisable(true);
                btnPaper.setDisable(true);
                btnScissors.setDisable(true);
                updateRPSWinInFile();
            } else if (num2 == 3) {
                suggestLabel.setText("You Lose this Round");
                btnRock.setDisable(true);
                btnPaper.setDisable(true);
                btnScissors.setDisable(true);
            }
            RPSLogic.upDateWinTimes(suggestLabel, user);
            winTimes.setText(Integer.toString(user.getRPSWin()));
        };

        btnRock.setOnAction(buttonHandler);
        btnPaper.setOnAction(buttonHandler);
        btnScissors.setOnAction(buttonHandler);

        HBox hBox2 = new HBox(50);
        hBox2.setAlignment(Pos.BOTTOM_CENTER);
        hBox2.getChildren().addAll(btnRock, btnPaper, btnScissors);

        Button resetBtn = new Button("RESET");
        resetBtn.setAlignment(Pos.BASELINE_CENTER);
        resetBtn.setMinSize(100, 50);

        resetBtn.setOnAction(e -> {
            playerImageView.setImage(null);
            computerImageView.setImage(null);
            resultLabel.setText(null);
            num1 = 0;
            num2 = 0;
            suggestLabel.setText("Choose the one you want to play");
            btnRock.setDisable(false);
            btnPaper.setDisable(false);
            btnScissors.setDisable(false);
        });
        VBox root = new VBox(30);
        root.setAlignment(Pos.CENTER);
        root.getChildren().addAll(menuHBox, suggestHBox, hBox2, hBox3, resetBtn);
        guessStage.setTitle("Guess Game");
        StackPane stackPane = new StackPane();
        stackPane.getChildren().addAll(bgRPSIV, root);
        guessStage.getIcons().add(RPSIcon);
        guessStage.setResizable(false);
        guessStage.setScene(new Scene(stackPane, 600, 600));
        guessStage.show();
    }

    private void updateRPSWinInFile() {
        try {
            List<String> lines = new ArrayList<>();
            File file = new File(ACCOUNTS_FILE);
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                lines.add(line);
            }
            scanner.close();

            for (int i = 0; i < lines.size(); i++) {
                String[] parts = lines.get(i).split(",");
                if (parts.length == 4 && parts[0].equals(user.getName())) {
                    int newRPSWin = Integer.parseInt(parts[2]) + 1;
                    parts[2] = Integer.toString(newRPSWin);
                    lines.set(i, String.join(",", parts));
                    break;
                }
            }

            PrintWriter writer = new PrintWriter(new FileWriter(ACCOUNTS_FILE));
            for (String line : lines) {
                writer.println(line);
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

