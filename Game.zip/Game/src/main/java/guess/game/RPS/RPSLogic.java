package guess.game.RPS;

import guess.game.GetImages;
import guess.game.Login.Login;
import javafx.scene.control.Label;
import java.util.Random;
import static guess.game.GetImages.computerImageView;

public class RPSLogic {
    private static final String Rock = "Rock";
    private static final String Paper = "Paper";
    private static final String Scissors = "Scissors";
    private static final String[] rps = {"Rock", "Paper", "Scissors"};
    private static final Random random = new Random();

    public static String buttonAction() {
        int randomIndex = random.nextInt(3);
        String computerChoice = rps[randomIndex];
        switch (computerChoice) {
            case Rock:
                computerImageView.setImage(GetImages.imageR);
                break;
            case Paper:
                computerImageView.setImage(GetImages.imageP);
                break;
            case Scissors:
                computerImageView.setImage(GetImages.imageS);
                break;
        }
        return computerChoice;
    }

    public static void checkWinner(String RPS, String computer, Label p) {
        if (RPS.equals(computer)) {
            p.setText("It's a Tie");
        } else if (RPS.equals("Rock") && computer.equals("Paper") ||
                RPS.equals("Scissors") && computer.equals("Rock") ||
                RPS.equals("Paper") && computer.equals("Scissors")
        ) {
            p.setText("You Lose");
        } else {
            p.setText("You Win");
        }
    }

    public static void upDateWinTimes(Label p, Login user) {
        if (p.getText().equals("You Win this Round")) {
            user.incrementRPSWin();
        }
    }

}

