package guess.game;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.IOException;

public interface GetImages {
    Image imageR = new Image("D:\\Intellij IDEA\\S2\\project\\Game\\src\\main\\resources\\rpsImage\\rock.png");
    ImageView imageViewR = new ImageView(imageR);

    Image imageP = new Image("D:\\Intellij IDEA\\S2\\project\\Game\\src\\main\\resources\\rpsImage\\paper.png");
    ImageView imageViewP = new ImageView(imageP);

    Image imageS = new Image("D:\\Intellij IDEA\\S2\\project\\Game\\src\\main\\resources\\rpsImage\\scissors.png");
    ImageView imageViewS = new ImageView(imageS);

    Image imageX = new Image("D:\\Intellij IDEA\\S2\\project\\Game\\src\\main\\resources\\TicTacToe\\xbutton.png");
    ImageView imageViewX = new ImageView(imageX);

    Image imageO = new Image("D:\\Intellij IDEA\\S2\\project\\Game\\src\\main\\resources\\TicTacToe\\obutton.png");
    ImageView imageViewO = new ImageView(imageO);

    ImageView playerImageView = new ImageView();
    ImageView computerImageView = new ImageView();
    Image RPSIcon = new Image("D:\\Intellij IDEA\\S2\\project\\Game\\src\\main\\resources\\rpsImage\\question.png");
    Image TTTIcon = new Image("D:\\Intellij IDEA\\S2\\project\\Game\\src\\main\\resources\\TicTacToe\\tictactoeIcon.png");

    Image backgroundRPS = new Image("D:\\Intellij IDEA\\S2\\project\\Game\\src\\main\\resources\\game\\background2.jpg");
    ImageView bgRPSIV = new ImageView(backgroundRPS);

    Image backgroundTTT = new Image("D:\\Intellij IDEA\\S2\\project\\Game\\src\\main\\resources\\game\\background1.jpg");
    ImageView bgTTTIV = new ImageView(backgroundTTT);

    Image backgroundMain = new Image("D:\\Intellij IDEA\\S2\\project\\Game\\src\\main\\resources\\game\\background.jpg");
    ImageView bgMainIV = new ImageView(backgroundMain);

}
