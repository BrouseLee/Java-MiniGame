package guess.game.TTT;

import guess.game.GetImages;
import guess.game.Login.Login;
import guess.game.Login.Main;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static guess.game.GetImages.TTTIcon;

public class TicTacToe extends Application {
    Button bt1 = new Button();
    Button bt2 = new Button();
    Button bt3 = new Button();
    Button bt4 = new Button();
    Button bt5 = new Button();
    Button bt6 = new Button();
    Button bt7 = new Button();
    Button bt8 = new Button();
    Button bt9 = new Button();
    Button[] buttons = new Button[9];
    private final Login user;

    public TicTacToe(Login user) {
        this.user = user;
    }

    private static final String ACCOUNTS_FILE = "accounts.txt";

    @Override
    public void start(Stage TTTStage) {

        MenuBar returnMenuBar = new MenuBar();
        returnMenuBar.setMinSize(70, 30);
        Menu stripMenu = new Menu("Return menu");
        returnMenuBar.getMenus().addAll(stripMenu);
        Menu returnMain = new Menu("Return to main menu");
        returnMain.setOnAction(e -> {
            Main mainStage = new Main();
            mainStage.start(new Stage());
            TTTStage.close();
        });
        stripMenu.getItems().addAll(returnMain);
        HBox menuHBox = new HBox();
        menuHBox.setAlignment(Pos.TOP_LEFT);
        menuHBox.getChildren().add(returnMenuBar);

        Label winTimesLabel = new Label("Win times: ");
        winTimesLabel.setTextFill(Color.WHITE);
        winTimesLabel.setFont(Font.font("Arial", 30));
        winTimesLabel.setMinSize(30, 50);
        Label winTimes = new Label();
        winTimes.setTextFill(Color.WHITE);
        winTimes.setFont(Font.font("Arial", 30));
        winTimes.setMinSize(30, 50);

        Label wordShow = new Label();
        wordShow.setTextFill(Color.WHITE);
        wordShow.setFont(Font.font("Arial", 80));
        wordShow.setMinSize(150, 100);
        HBox wordHBox = new HBox();
        wordHBox.setAlignment(Pos.TOP_CENTER);
        wordHBox.getChildren().addAll(wordShow);

        buttons = new Button[]{bt1, bt2, bt3, bt4, bt5, bt6, bt7, bt8, bt9};
        initButtons(buttons);

        EventHandler<ActionEvent> buttonHandler = e -> {
            Button button = (Button) e.getSource();
            TicTacToeLogic.handleMove(button, buttons, wordShow);
            switch (TicTacToeLogic.checkWinner(buttons)) {
                case "X":
                    wordShow.setText("You Win!");
                    disableButtons(buttons);
                    break;
                case "O":
                    wordShow.setText("Computer Win!");
                    disableButtons(buttons);
                    break;
                default:
                    break;
            }
            if (wordShow.getText().equals("You Win!")) {
                updateTTTWinInFile();

            }
            TicTacToeLogic.upDateWinTimes(wordShow, user);
            winTimes.setText(Integer.toString(user.getTTTWin()));
        };
        bt1.setOnAction(buttonHandler);
        bt2.setOnAction(buttonHandler);
        bt3.setOnAction(buttonHandler);
        bt4.setOnAction(buttonHandler);
        bt5.setOnAction(buttonHandler);
        bt6.setOnAction(buttonHandler);
        bt7.setOnAction(buttonHandler);
        bt8.setOnAction(buttonHandler);
        bt9.setOnAction(buttonHandler);

        HBox hBox0 = new HBox(130);
        hBox0.setAlignment(Pos.TOP_CENTER);
        hBox0.getChildren().addAll(menuHBox, winTimesLabel, winTimes);

        HBox hBox1 = new HBox(1);
        hBox1.setAlignment(Pos.CENTER);
        hBox1.getChildren().addAll(bt1, bt2, bt3);
        HBox hBox2 = new HBox(1);
        hBox2.setAlignment(Pos.CENTER);
        hBox2.getChildren().addAll(bt4, bt5, bt6);
        HBox hBox3 = new HBox(1);
        hBox3.setAlignment(Pos.CENTER);
        hBox3.getChildren().addAll(bt7, bt8, bt9);

        VBox vB = new VBox(1);
        vB.setAlignment(Pos.CENTER);
        vB.getChildren().addAll(hBox1, hBox2, hBox3);

        Button reset = new Button("RESET");
        reset.setMinSize(100, 50);
        reset.setOnAction(e -> {
            for (int i = 0; i < 9; i++) {
                buttons[i].setText("");
            }
            wordShow.setText("");
            undisable(buttons);
        });
        HBox resetBox = new HBox();
        resetBox.setAlignment(Pos.BASELINE_CENTER);
        resetBox.getChildren().addAll(reset);

        VBox vBox = new VBox(30);
        vBox.getChildren().addAll(hBox0, wordHBox, vB, resetBox);
        StackPane stackPane = new StackPane();
        stackPane.getChildren().addAll(GetImages.bgTTTIV, vBox);
        TTTStage.setScene(new Scene(stackPane, 600, 600));
        TTTStage.setTitle("Tic Tac Toe");
        TTTStage.setResizable(false);
        TTTStage.getIcons().add(TTTIcon);
        TTTStage.show();
    }

    private void initButtons(Button[] buttons) {
        for (int i = 0; i < 9; i++) {
            buttons[i].setMinSize(100, 100);
            buttons[i].setText("");
            buttons[i].setFont(Font.font("Arial", 35));
            buttons[i].setMinSize(100, 100);
            buttons[i].setMaxSize(100, 100);
        }
    }
    private void disableButtons(Button[] buttons){
        for (int i = 0; i < 9; i++) {
            buttons[i].setDisable(true);
        }
    }
    private void undisable(Button[] buttons){
        for (int i = 0; i < 9; i++) {
            buttons[i].setDisable(false);
        }
    }
    private void updateTTTWinInFile() {
        try {
            List<String> lines = new ArrayList<>();
            File file = new File(ACCOUNTS_FILE);
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                lines.add(line);
            }
            scanner.close();

            for (int i = 0; i < lines.size(); i++) {
                String[] parts = lines.get(i).split(",");
                if (parts.length == 4 && parts[0].equals(user.getName())) {
                    int newTTTWin = Integer.parseInt(parts[3]) + 1;
                    parts[3] = Integer.toString(newTTTWin);
                    lines.set(i, String.join(",", parts));
                    break;
                }
            }

            PrintWriter writer = new PrintWriter(new FileWriter(ACCOUNTS_FILE));
            for (String line : lines) {
                writer.println(line);
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
