package guess.game.TTT;

import guess.game.Login.Login;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import java.util.Random;

public class TicTacToeLogic {
    public static void handleMove(Button button, Button[] buttons, Label p) {
        if (button.getText().isEmpty()) {
            button.setText("X");
            while (checkFull(buttons)) {
                int index = new Random().nextInt(9);
                if (buttons[index].getText().isEmpty()) {
                    buttons[index].setText("O");
                    break;
                }
            }
        }
        if (!checkFull(buttons)){
            p.setText("It's a Tie");
        }
    }

    private static boolean checkFull(Button[] buttons) {
        int count = 0;
        for (int i = 0; i < 9; i++) {
            if (!buttons[i].getText().isEmpty()) {
                count++;
                if (count == 9) {
                    return false;
                }
            }
        }
        return true;
    }

    public static boolean checkWin(String symbol, Button[] buttons) {
        return (buttons[0].getText().equals(symbol) && buttons[1].getText().equals(symbol) && buttons[2].getText().equals(symbol)) ||
                (buttons[3].getText().equals(symbol) && buttons[4].getText().equals(symbol) && buttons[5].getText().equals(symbol)) ||
                (buttons[6].getText().equals(symbol) && buttons[7].getText().equals(symbol) && buttons[8].getText().equals(symbol)) ||
                (buttons[0].getText().equals(symbol) && buttons[3].getText().equals(symbol) && buttons[6].getText().equals(symbol)) ||
                (buttons[1].getText().equals(symbol) && buttons[4].getText().equals(symbol) && buttons[7].getText().equals(symbol)) ||
                (buttons[2].getText().equals(symbol) && buttons[5].getText().equals(symbol) && buttons[8].getText().equals(symbol)) ||
                (buttons[0].getText().equals(symbol) && buttons[4].getText().equals(symbol) && buttons[8].getText().equals(symbol)) ||
                (buttons[2].getText().equals(symbol) && buttons[4].getText().equals(symbol) && buttons[6].getText().equals(symbol));
    }

    public static boolean checkPlayerWin(Button[] buttons) {
        return checkWin("X", buttons);
    }

    public static boolean checkComputerWin(Button[] buttons) {
        return checkWin("O", buttons);
    }

    public static String checkWinner(Button[] buttons) {
        if (checkPlayerWin(buttons)) {
            return "X";
        } else if (checkComputerWin(buttons)) {
            return "O";
        } else {
            return "";
        }
    }
    public static void upDateWinTimes(Label p, Login user) {
        if (p.getText().equals("You Win!")) {
            user.incrementTTTWin();
        }
    }
}
