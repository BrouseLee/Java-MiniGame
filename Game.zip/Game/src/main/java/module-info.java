module guess.game {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.almasb.fxgl.all;
    requires javafx.media;

    opens guess.game to javafx.fxml;
    opens TicTacToe to javafx.fxml;
    exports guess.game;
    exports guess.game.TTT;
    opens guess.game.TTT to javafx.fxml;
    exports guess.game.RPS;
    opens guess.game.RPS to javafx.fxml;
    exports guess.game.Login;
    opens guess.game.Login to javafx.fxml;

}